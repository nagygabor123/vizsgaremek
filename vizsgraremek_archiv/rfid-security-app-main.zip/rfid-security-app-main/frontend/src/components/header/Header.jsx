import React from "react";
import "./header.css";

export default function Header() {
  return (
    <div className="projectHeader">
      <h1>Students RFID System</h1>
    </div>
  );
}
