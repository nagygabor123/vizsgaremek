# Build a Better Responsive Admin Dashboard UI


Admin dashboards are among the most common user interfaces you’ll come across as a web developer. They’re a great practice ground for coding, because they include so many UI elements. In this course we’ll build a simple responsive admin dashboard UI, which features a collapsible sidebar, icons, and a dark mode toggle switch.
